import { Component, OnInit, ViewChild, TemplateRef, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder } from "@angular/forms";
import Swal from 'sweetalert2';
import 'datatables.net';
import 'datatables.net-bs4';
import * as $ from 'jquery';
import { BsModalService, ModalOptions } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BranchModel } from '../../shared/model/BranchModel';
import { BranchMasterService } from '../../shared/service-proxy/branchMasterService';
import { RegularClientModel } from '../../shared/model/RegularClientModel';
import { RegularClientMasterService } from '../../shared/service-proxy/regularClientMasterService';
import { CityMasterService } from '../../shared/service-proxy/cityMasterService';
import { StateMasterService } from '../../shared/service-proxy/stateMasterService';
import { CityModel } from '../../shared/model/CityModel';
import { StateModel } from '../../shared/model/StateModel';


const swalWithBootstrapButtons = Swal.mixin({
  confirmButtonClass: 'btn btn-raised shadow-z-2 btn-success',
  cancelButtonClass: 'btn btn-raised shadow-z-2 btn-danger',
  buttonsStyling: true,
  customClass: "mycustomBTNclass",
});


@Component({
  selector: 'app-regular-client-master',
  templateUrl: './regular-client-master.component.html',
  styleUrls: ['./regular-client-master.component.scss']
})
export class RegularClientMasterComponent implements OnInit {


  @ViewChild('template') template: TemplateRef<any>;
  RegularClientMasterForm: FormGroup;
  RCM: RegularClientModel;
  rows: any[];

  dataTable: any;
  Title: string;
  AllCities: CityModel[] = [];
  cities: CityModel[] = [];
  states: StateModel[] = [];

  modalRef: BsModalRef;
  config: ModalOptions = {
    backdrop: true,
    ignoreBackdropClick: true,
    class: 'modal-lg'
  };

  Branches: BranchModel[] = [];

  constructor(private fb: FormBuilder,
    private changeDetectorRef: ChangeDetectorRef,
    private modalService: BsModalService,
    private branchService: BranchMasterService,
    private regularClientService: RegularClientMasterService,
    private cityService: CityMasterService,
    private service: StateMasterService
  ) { }

  ngOnInit() {
    this.BranchList();
    this.RegularClientList();
    this.CitiesList();
    this.StatesList();
    this.LoadForm();
  }

  LoadForm() {
    this.Title = "Add New Regular Client";
    this.RegularClientMasterForm = this.fb.group({
      id: [''],
      branchId: [''],
      clientCode: [''],
      clientName: [''],
      clientGroupId: [''],
      pan: [''],
      gstIN: [''],
      address: [''],
      cityId: [''],
      pinCode: [''],
      StateId: [''],
      phoneNo: [''],
      mobileNo: [''],
      emailAlert: [''],
      smsAlert: [''],
      deliveryAgainstAsCnr: [''],
      deliveryAgainstAsCne: [''],
      ledgerName: [''],
      days: [''],
      amount: [''],
      interest: [''],
      creditGraceDays: [''],
      bankId: [''],
      accountNo: [''],
      chequeheNameOf: [''],
      companyNo: [''],
      policyNo: [''],
      validFromDate: [''],
      validToDate: [''],
      insuranceAmount: [''],
      isMarineInsured: [''],
      isGodownInsured: [''],
      paymentMode: [''],
      bookingType: [''],
      deliveryType: [''],
      multipleBillingBranches: [''],
      remark: ['']
    });
  }

  BranchList() {
    this.branchService.GetBranches().subscribe((res: BranchModel[]) => {
      this.Branches = res;
    });
  }

  RegularClientList() {
    this.regularClientService.GetRegularClients().subscribe((res: RegularClientModel[]) => {
      this.rows = res;
      this.changeDetectorRef.detectChanges();
      const table: any = $('table');
      this.dataTable = table.DataTable();
    });
  }


  ShowPopUp() {
    this.modalRef = this.modalService.show(this.template, this.config);
  }

  HidePopUp() {
    this.modalRef.hide();
    this.RegularClientMasterForm.reset();
  }

  SaveDetail() {
    let obj = Object.assign({}, this.RCM, this.RegularClientMasterForm.value);
    if (this.RegularClientMasterForm.dirty) {
      this.regularClientService.SaveRegularClient(obj).subscribe((response: boolean) => {
        this.HidePopUp();
        this.Destroy();
        if (response) {
          Swal({
            position: 'center',
            type: 'success',
            title: 'Godown has been saved',
            showConfirmButton: false,
            timer: 1500
          });
        }
        this.RegularClientList();
      });
    }
  }

  ShowData(data: number) {
    this.Title = "Edit Godown";
    this.cities = this.AllCities;
    this.regularClientService.GetRegularClient(data).subscribe((res: RegularClientModel) => {
      this.RegularClientMasterForm.patchValue({
        id: res.id,
        branchId: res.branchId,
        clientCode: res.clientCode,
        clientName: res.clientName,
        clientGroupId: res.clientGroupId,
        pan: res.pan,
        gstIN: res.gstIN,
        address: res.address,
        cityId: res.cityId,
        pinCode: res.pinCode,
        StateId: res.StateId,
        phoneNo: res.phoneNo,
        mobileNo: res.mobileNo,
        emailAlert: res.emailAlert,
        smsAlert: res.smsAlert,
        deliveryAgainstAsCnr: res.deliveryAgainstAsCnr,
        deliveryAgainstAsCne: res.deliveryAgainstAsCne,
        ledgerName: res.ledgerName,
        days: res.days,
        amount: res.amount,
        interest: res.interest,
        creditGraceDays: res.creditGraceDays,
        bankId: res.bankId,
        accountNo: res.accountNo,
        chequeheNameOf: res.chequeheNameOf,
        companyNo: res.companyNo,
        policyNo: res.policyNo,
        validFromDate: res.validFromDate,
        validToDate: res.validToDate,
        insuranceAmount: res.insuranceAmount,
        isMarineInsured: res.isMarineInsured,
        isGodownInsured: res.isGodownInsured,
        paymentMode: res.paymentMode,
        bookingType: res.bookingType,
        deliveryType: res.deliveryType,
        multipleBillingBranches: res.multipleBillingBranches,
        remark: res.remark
      });
      this.ShowPopUp();
    });
  }

  DeleteRegularClient(id: number) {

    swalWithBootstrapButtons({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      reverseButtons: true
    }).then((result) => {
      if (result.value) {
        this.regularClientService.DeleteRegularClient(id)
          .subscribe(() => {
            this.Destroy();
            this.RegularClientList();
          });
        swalWithBootstrapButtons(
          'Deleted!',
          'Your file has been deleted.',
          'success'
        );
      } else if (
        result.dismiss === Swal.DismissReason.cancel
      ) {
        swalWithBootstrapButtons(
          'Cancelled',
          'Data is safe :)',
          'info'
        )
      }
    });
  }

  Destroy() {
    const table: any = $('table');
    table.DataTable();
    table.DataTable().destroy();
  }

  public Validator(event: any) {
    const pattern = /^[0-9]*$/;
    if (!pattern.test(event.target.value)) {
      event.target.value = event.target.value.replace(/[^0-9]/g, "");
    }
  }

  CitiesList() {
    this.cityService.GetCities().subscribe((res: CityModel[]) => {
      this.AllCities = res;
    });
  }
  StatesList() {
    this.service.GetStates().subscribe((res: StateModel[]) => {
      this.states = res;
    });
  }
  onChange(data) {
    this.cities = this.AllCities.filter(x => x.stateId == parseInt(data));
  }
}
