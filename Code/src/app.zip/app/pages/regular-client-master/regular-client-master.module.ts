import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { RegularClientMasterComponent } from './regular-client-master.component';
import { VirtualGodownMasterRoutingModule } from './regular-client-master-routing.module';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
    imports: [
        CommonModule,
        VirtualGodownMasterRoutingModule,
        ReactiveFormsModule,
    ],
    declarations: [      
        RegularClientMasterComponent,
    ]
})
export class RegularClientMasterModule { }