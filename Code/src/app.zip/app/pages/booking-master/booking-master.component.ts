import { Component, OnInit, ChangeDetectorRef, ViewChild, TemplateRef } from '@angular/core';
import Swal from 'sweetalert2';
import 'datatables.net';
import 'datatables.net-bs4';
import * as $ from 'jquery';
import { FormBuilder, FormGroup } from '@angular/forms';
import { BookingMasterService } from '../../shared/service-proxy/bookingMasterService';
import { BookingModel } from '../../shared/model/BookingModel';
import { BsModalRef, BsModalService, ModalOptions } from 'ngx-bootstrap';
import { GodownMasterService } from '../../shared/service-proxy/godownMasterService';
import { GodownModel } from '../../shared/model/GodownModel';
import { RegularClientMasterService } from '../../shared/service-proxy/regularClientMasterService';
import { RegularClientModel } from '../../shared/model/RegularClientModel';
import { BranchModel } from '../../shared/model/BranchModel';
import { BranchMasterService } from '../../shared/service-proxy/branchMasterService';
import swal from 'sweetalert2';
import { DatePipe } from '@angular/common';
const swalWithBootstrapButtons = Swal.mixin({
  confirmButtonClass: 'btn btn-raised shadow-z-2 btn-success',
  cancelButtonClass: 'btn btn-raised shadow-z-2 btn-danger',
  buttonsStyling: true,
  customClass: "mycustomBTNclass"
});
@Component({
  selector: 'app-booking-master',
  templateUrl: './booking-master.component.html',
  styleUrls: ['./booking-master.component.scss']
})
export class BookingMasterComponent implements OnInit {
  rows: any[];
  dataTable: any;
  modalRef: BsModalRef;
  bm:BookingModel;
  title:string;
  BookingMasterForm:FormGroup;
  from:BranchModel[]=[];
  to:BranchModel[]=[];
  PaymentBox=[];
  all:BranchModel[]=[];
  Goddowns:GodownModel[]=[];
  AllConsignee:RegularClientModel[]=[];
  AllGoddowns:GodownModel[]=[];
  config: ModalOptions = {
    backdrop: true,
    ignoreBackdropClick: true,
    class: "modal-lg"
  };
  
  branchMasterForm: FormGroup;
  @ViewChild('template') template: TemplateRef<any>;
  constructor(private fb: FormBuilder, private service: BookingMasterService
    , private changeDetectorRef: ChangeDetectorRef, private modalService: BsModalService,
    private goddownService:GodownMasterService,private consigneeService:RegularClientMasterService,
    private branchService:BranchMasterService,private datePipe:DatePipe) { }

  ngOnInit() {
   this.LoadForm();
    this.GetBookingList();
   this.GoddownAll();
   this.ConsigneeAll();
   this.PaymentBoxes();
   this.fromtoAll();
  }
  GetBookingList() {
    debugger
    this.service.GetBookings().subscribe((res: BookingModel[]) => {
      this.rows = res;
    
      this.changeDetectorRef.detectChanges();
      const table: any = $('table');
      this.dataTable = table.DataTable();
    });
    
  }
  ShowPopUp(){
    this.modalRef=this.modalService.show(this.template,this.config);
  }
  HidePopUp() {
    this.modalRef.hide();
    this.BookingMasterForm.reset();
  }
  GoddownAll(){
  this.goddownService.GetGodowns().subscribe((res:GodownModel[])=>{
    this.AllGoddowns=res;
  
  })
  }
    ConsigneeAll(){
      this.consigneeService.GetRegularClients().subscribe((res:RegularClientModel[])=>{
      this.AllConsignee=res;
      })
    }
    PaymentBoxes(){
      this.PaymentBox=[{
        id:1,
        Name:"ToPay"
      },
      {
        id:2,
        Name:"To be billed"
      },
    {
      id:3,
      Name:"Paid"
    },
    {
      id:4,
      Name:"FOC"
    },
    {
      id:5,
      Name:"Rebook"
    }
    ]
    }
    fromtoAll(){
  this.branchService.GetBranches().subscribe((res:BranchModel[])=>{
    this.from=res;
    this.all=res;
  })
    }
    SaveBooking(Data:BookingModel){
      debugger
      let id = this.BookingMasterForm.controls.id.value;
      let cn = this.BookingMasterForm.controls.cn.value;
      let from = this.BookingMasterForm.controls.from.value;
      let to = this.BookingMasterForm.controls.to.value;
      let godownNo = this.BookingMasterForm.controls.godownNo.value;
      let paymentType = this.BookingMasterForm.controls.paymentType.value;
      let actualWeight = this.BookingMasterForm.controls.actualWeight.value;
      let consignee = this.BookingMasterForm.controls.consignee.value;
      let expectedDelivery=this.BookingMasterForm.controls.expectedDelivery.value;
      let obj=Object.assign({},this.bm,{

        id:id,
        cn:cn,
        from:from,
        to:to,
        godownNo:godownNo,
        paymentType:paymentType,
        actualWeight:actualWeight,
        consignee:consignee,
        expectedDelivery:expectedDelivery
      });
      if(this.BookingMasterForm.dirty){
        this.service.SaveBookings(obj).subscribe((response:any)=>{
          this.HidePopUp();
          this.Destroy();
          if(response){
            swal({
              position:'center',
              type:'success',
              title:'Booking has been saved',
              showConfirmButton:false,
              timer:1500
            });
          }
          this.LoadForm();
          this.GetBookingList();
        })
      }
    }
    Destroy() {
      const table: any = $('table');
      table.DataTable();
      table.DataTable().destroy();
  }
  LoadForm(){
    this.title="Add new Booking";
    this.BookingMasterForm=this.fb.group({
      id:['0'],
      cn:[''],
      expectedDelivery:[''],
      from:[''],
      to:[''],
      godownNo:[''],
      paymentType:[''],
      actualWeight:[''],
      consignee:['']
    });
  }
  DeleteBookings(id:number){
  swalWithBootstrapButtons({
    title:'Are you sure?',
    text:"you won't be revert this!",
    type:'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, delete it!',
    cancelButtonText: 'No, cancel!',
    reverseButtons: true
  }).then((result)=>{
    if(result.value){
      this.service.DeleteBooking(id)
        .subscribe(()=>{
          this.Destroy();
          this.GetBookingList();
        });
        swalWithBootstrapButtons(
          'Deleted!',
          'Your file has been deleted.',
          'success'
      );
    }
    else if(result.dismiss===swal.DismissReason.cancel){
      swalWithBootstrapButtons(
        'Cancelled',
        'Data is safe :)',
        'info'
    )
    }
  })
  }

  ShowData(data:number){
    debugger
    this.title="Edit Booking";
    // var cn = this.datePipe.transform(res.dateofBirth, 'yyyy-MM-dd');
    this.service.GetBooking(data).subscribe((res:BookingModel)=>{
      var date1 = this.datePipe.transform(res.cn, 'yyyy-MM-dd');
      var date2 = this.datePipe.transform(res.expectedDelivery, 'yyyy-MM-dd');

      this.BookingMasterForm.patchValue({
        
        id:data,
        cn:date1,
        from:res.from,
        to:res.to,
        godownNo:res.godownNo,
        paymentType:res.paymentType,
        actualWeight:res.actualWeight,
        consignee:res.consignee,
        expectedDelivery:date2
      });
      this.ShowPopUp();
    })
  }
  GetGodown(id:number){
   
    this.goddownService.GetGodown(id).subscribe((res:any)=>{
      this.Goddowns=res;
    })
  }
}
