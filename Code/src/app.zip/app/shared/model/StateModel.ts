export class StateModel{
    Id : number;
    StateName : string;
    GSTCode : number;
    StateRtoCode : string;
    Remark : string;
}