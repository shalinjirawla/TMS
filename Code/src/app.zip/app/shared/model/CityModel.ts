export class CityModel{
    id : number;
    stateId : number;
    cityCode : string;
    cityName : string;
    remark : string;
}
