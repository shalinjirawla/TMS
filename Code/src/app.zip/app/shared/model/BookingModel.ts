export class BookingModel{
    id:number;
    cn:Date;
    expectedDelivery:Date;
    from:number;
    to:number;
    godownNo:number;
    paymentType:string;
    actualWeight:number;
    consignee:number;
}