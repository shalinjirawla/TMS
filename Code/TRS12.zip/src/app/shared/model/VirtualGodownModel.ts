export class VirtualGodownModel {
    id: number;
    virtualGodownCode: string;
    branchId: number;
    godownId: number;
    storageCapacity: string;
    remark: string;
}