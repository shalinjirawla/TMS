import { RouteInfo } from './sidebar.metadata';

export const ROUTES: RouteInfo[] = [

    {
        path: '/full-layout', title: 'Full Layout', icon: 'ft-layout', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: []
    },
    {
        path: '/home', title: 'Home Page', icon: 'ft-square', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: []
    },
    {
        path: '', title: 'Masters', icon: 'ft-align-left', class: 'has-sub', badge: '', badgeClass: 'badge badge-pill badge-danger float-right mr-1 mt-1', isExternalLink: false,
        submenu: [
            { 
                path: '/statemaster', title: 'State', icon: 'icon-crop', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: []
            },            
            {
                path: '/citymaster', title: 'City', icon: 'icon-plane', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: []
            },
            {
                path: '/regionmaster', title: 'Region', icon: 'icon-energy', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: []
            },
            {
                path: '/branchmaster', title: 'Branch', icon: 'icon-anchor', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: []
            },
            {
                path: '/godownmaster', title: 'Godown', icon: 'ft-layers', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: []
            },
            {
                path: '/virtualgodownmaster', title: 'Virtual Godown', icon: 'ft-sliders', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: []
            },
            {
                path: '/regularclientmaster', title: 'Regular Client', icon: 'ft-sliders', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: []
            },
            {
                path: '/bookingmaster', title: 'Booking Client', icon: 'ft-sliders', class: '', badge: '', badgeClass: '', isExternalLink: false, submenu: []
            },
        ]
    }
];
