import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegularClientMasterComponent } from './regular-client-master.component';

describe('RegularClientMasterComponent', () => {
  let component: RegularClientMasterComponent;
  let fixture: ComponentFixture<RegularClientMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegularClientMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegularClientMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
