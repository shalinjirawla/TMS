import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from "./shared/shared.module";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { ContentLayoutComponent } from "./layouts/content/content-layout.component";
import { FullLayoutComponent } from "./layouts/full/full-layout.component";
import { StateMasterService } from './shared/service-proxy/stateMasterService';
import { CityMasterService } from './shared/service-proxy/cityMasterService';
import { RegionMasterService } from './shared/service-proxy/regionMasterService';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BranchMasterService } from './shared/service-proxy/branchMasterService';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { GodownMasterService } from './shared/service-proxy/godownMasterService';
import { VirtualGodownMasterService } from './shared/service-proxy/virtualGodownMasterService';
import { RegularClientMasterService } from './shared/service-proxy/regularClientMasterService';
import { BookingMasterService } from './shared/service-proxy/bookingMasterService';
import {DatePipe} from '@angular/common';


@NgModule({
    declarations: [
        AppComponent,
        FullLayoutComponent,
        ContentLayoutComponent,

    ],
    imports: [
        BrowserAnimationsModule,
        AppRoutingModule,
        SharedModule,
        NgbModule.forRoot(),
        HttpClientModule,
        ModalModule.forRoot(),
        TooltipModule.forRoot(),
      
    ],
    providers: [StateMasterService,CityMasterService
    ,RegionMasterService,BranchMasterService,
    GodownMasterService,VirtualGodownMasterService,
    RegularClientMasterService,BookingMasterService,DatePipe],
    bootstrap: [AppComponent]
})
export class AppModule { }