# [Matngular - Bootstrap 4 Material 2 Angular 4 Admin Template]


### Changelog
***

#### `1.0` (2017-10-01)
***

Initial release