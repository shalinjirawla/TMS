import { Routes, RouterModule } from '@angular/router';

//Route for content layout with sidebar, navbar and footer
export const Full_ROUTES: Routes = [
  {
    path: 'full-layout',
    loadChildren: './pages/full-layout-page/full-pages.module#FullPagesModule'
  },
  {
    path : 'home',
    loadChildren : './pages/home/home.module#HomeModule'
  },
  {
    path : 'statemaster',
    loadChildren : './pages/state-master/state-master.module#StateMasterModule'
  },
  {
    path : 'citymaster',
    loadChildren : './pages/city-master/city-master.module#CityMasterModule'
  },
  {
    path : 'regionmaster',
    loadChildren : './pages/region-master/region-master.module#RegionMasterModule'
  },
  {
    path : 'branchmaster',
    loadChildren : './pages/branch-master/branch-master.module#BranchMasterModule'
  },
  {
    path : 'godownmaster',
    loadChildren : './pages/godown-master/godown-master.module#GodownMasterModule'
  },
  {
    path : 'virtualgodownmaster',
    loadChildren : './pages/virtual-godown-master/virtual-godown-master.module#VirtualGodownMasterModule'
  },
  {
    path : 'regularclientmaster',
    loadChildren : './pages/regular-client-master/regular-client-master.module#RegularClientMasterModule'
  },
  {
    path:'bookingmaster',
    loadChildren:'./pages/booking-master/booking-master.module#BookingMasterModule'
  }
];